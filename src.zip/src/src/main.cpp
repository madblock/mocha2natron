// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "stdio.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// The one and only application object

CWinApp theApp;

using namespace std;

CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> getSection(CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> &srcString, int first, int second);

int main()
{
    int nRetCode = 0;

    HMODULE hModule = ::GetModuleHandle(nullptr);

    if (hModule != nullptr)
    {
        // initialize MFC and print and error on failure
        if (!AfxWinInit(hModule, nullptr, ::GetCommandLine(), 0))
        {
            // TODO: change error code to suit your needs
            wprintf(L"Fatal Error: MFC initialization failed\n");
            nRetCode = 1;
        }
        else
        {
			printf("\nmocha2natron 0.1\n\nMake sure you just copied to Clipboard tracking data from Mocha as AE corner pin only.\n\n");

			CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>>  source;
			if (OpenClipboard(NULL))//��������� ����� ������
			{
				HANDLE hData = GetClipboardData(CF_TEXT);//��������� ����� �� ������ ������
				char* chBuffer = (char*)GlobalLock(hData);//��������� ������
				source = chBuffer;
				GlobalUnlock(hData);//������������ ������
				CloseClipboard();//��������� ����� ������
				//printf(source.GetBuffer(0));
				//printf("\nSuccess!\n");
			}


			// check right Clipboard given
			if (source.Find("Position") != -1 || source.Find("ADBE Corner Pin-0004") == -1)
			{
				printf("Wrong Clipboard.\n\n");
				system("pause");
				return 0;
			}

			CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> result, templ, myInt, str;

			try
			{
				// try to open the file
				CFile xmlTempl(L"m2n_template.xml", CFile::modeRead);

				// print out path name and title information
				/*
				_tprintf_s(_T("Path is : \"%s\"\n"),
					(LPCTSTR)xmlTempl.GetFilePath());
				_tprintf_s(_T("Name is : \"%s\"\n"),
					(LPCTSTR)xmlTempl.GetFileName());
				_tprintf_s(_T("Title is: \"%s\"\n"),
					(LPCTSTR)xmlTempl.GetFileTitle());
					*/
				UINT nBytes = (UINT)xmlTempl.GetLength();
				UINT nBytesRead = xmlTempl.Read(templ.GetBuffer(nBytes + 1), nBytes);
				templ.ReleaseBuffer(nBytesRead);
				// close the file handle
				xmlTempl.Close();
			}
			catch (CFileException* pEx)
			{
				wprintf(L"Template file \"m2n_template.xml\" not found\n\n");
				system("pause");
				return 0;
			}
			catch (...)
			{
				wprintf(L"Unknown error\n");
				system("pause");
				return 0;
			}

			char cInputline[15];
			wprintf(L"First frame: ");
			gets_s(cInputline,12);
			int frameOffset = atoi(cInputline);

			int wdthPos = source.Find("Source Width")+13;
			int wdth = atoi(source.Mid(wdthPos,5));
			myInt.Format("%d", wdth);
			templ.Replace("<!--WDTH-->", myInt);
			// catch
			wdthPos = source.Find("Source Height") + 14;
			int frameHeight = atoi(source.Mid(wdthPos, 5));
			myInt.Format("%d", frameHeight);
			templ.Replace("<!--HGHT-->", myInt);
			// catch
			
			int framesCount = 0;
			char *pEnd = source.GetBuffer(source.GetLength()+1);
			pEnd += source.Find("ADBE Corner Pin") + 68; // Catch not RGWarp
			while (pEnd[0] != '\0' && pEnd[0] != 'E')
			{
				double fValue = strtod(pEnd, &pEnd);
				/*
				myInt.Format("%f\n", fValue);
				printf(myInt);*/
				framesCount++;
				
				while ((pEnd[0] < '0' || pEnd[0] > '9') && (pEnd[0] != '\0' && pEnd[0] != 'E')) pEnd++;
			}
			source.ReleaseBuffer();

			framesCount /= 3;
			myInt.Format("%d", framesCount);
			templ.Replace("<!--CNT-->", myInt);

			// composing result from template
			int i = 0, j = 0;
			double fTime, fTimeBefore, fTimeAfter, fValue, fValueBefore, fValueAfter, fDerivative;
			char *sourceBuf = source.GetBuffer(source.GetLength()+1);
			char *cursor = sourceBuf;
			result = getSection(templ,j,i);
			int partOffset[4];
			partOffset[0] = source.Find("ADBE Corner Pin-0003") + 49;
			partOffset[1] = source.Find("ADBE Corner Pin-0004") + 49;
			partOffset[2] = source.Find("ADBE Corner Pin-0002") + 49;
			partOffset[3] = source.Find("ADBE Corner Pin-0001") + 49;

			for (j = 0; j < 4; j++)
			{
				cursor = sourceBuf + partOffset[j];
				// writing X
				fTimeAfter = strtod(cursor, &cursor); // time
				fTimeAfter += frameOffset;
				fValueAfter = strtod(cursor, &cursor); // X
				strtod(cursor, &cursor); // skip Y
				for (i = 0; i < framesCount; i++)
				{
					fTimeBefore = fTime;
					fValueBefore = fValue;
					fTime = fTimeAfter;
					fValue = fValueAfter;
					if (i < framesCount - 1)
					{
						fTimeAfter = strtod(cursor, &cursor); // time
						fTimeAfter += frameOffset;
						fValueAfter = strtod(cursor, &cursor); // X
						strtod(cursor, &cursor); // skip Y
						if (i == 0) fDerivative = (fValueAfter - fValue) / (fTimeAfter - fTime);
						else fDerivative = (fValueAfter - fValueBefore) / (fTimeAfter - fTimeBefore);
					} else fDerivative = (fValue - fValueBefore) / (fTime - fTimeBefore);

					myInt.Format("%f", fTime);
					result += myInt;
					result += getSection(templ, j * 2, 2); // XML after time
					
					myInt.Format("%f", fValue);
					result += myInt;
					result += getSection(templ, j * 2, 3); // XML after value
					
					myInt.Format("%f", fDerivative);
					result += myInt; // LeftDerivative
					result += getSection(templ, j * 2, 4);
					result += myInt; // RightDerivative
					if (i < framesCount - 1) result += getSection(templ, j * 2, 5);
					else result += getSection(templ, j * 2, 9); // terminating
				}

				cursor = sourceBuf + partOffset[j];
				// writing Y
				fTimeAfter = strtod(cursor, &cursor); // time
				fTimeAfter += frameOffset;
				strtod(cursor, &cursor); // skip X
				fValueAfter = strtod(cursor, &cursor); // Y
				fValueAfter = frameHeight - fValueAfter; // invert
				for (i = 0; i < framesCount; i++)
				{
					fTimeBefore = fTime;
					fValueBefore = fValue;
					fTime = fTimeAfter;
					fValue = fValueAfter;
					if (i < framesCount - 1)
					{
						fTimeAfter = strtod(cursor, &cursor); // time
						fTimeAfter += frameOffset;
						strtod(cursor, &cursor); // skip X
						fValueAfter = strtod(cursor, &cursor); // Y
						fValueAfter = frameHeight - fValueAfter;
						if (i == 0) fDerivative = (fValueAfter - fValue) / (fTimeAfter - fTime);
						else fDerivative = (fValueAfter - fValueBefore) / (fTimeAfter - fTimeBefore);
					}
					else fDerivative = (fValue - fValueBefore) / (fTime - fTimeBefore);

					myInt.Format("%f", fTime);
					result += myInt;
					result += getSection(templ, j * 2 + 1, 2); // XML after time

					myInt.Format("%f", fValue);
					result += myInt;
					result += getSection(templ, j * 2 + 1, 3); // XML after value

					myInt.Format("%f", fDerivative);
					result += myInt; // LeftDerivative
					result += getSection(templ, j * 2 + 1, 4);
					result += myInt; // RightDerivative
					if (i < framesCount - 1) result += getSection(templ, j * 2 + 1, 5);
					else result += getSection(templ, j * 2 + 1, 9); // terminating
				}
			}

			source.ReleaseBuffer();
/*			CString str;
			m_edtMyEditBox.GetWindowText(str);
			char *pEnd;
			double dValue = strtod(str.GetBuffer(str.GetLength()), &pEnd);
			if (*pEnd != '\0')
			{
				// Error in parsing
			}
			str.ReleaseBuffer();
			*/

			//result = templ;
/*			result.SetAt(5,'!');
			result += "Success!";*/

			
			if (OpenClipboard(NULL))//��������� ����� ������
			{
				HGLOBAL hgBuffer;
				char* chBuffer;
				EmptyClipboard(); //������� �����
				hgBuffer = GlobalAlloc(GMEM_DDESHARE, result.GetLength()+1);//�������� ������
				
				chBuffer = (char*)GlobalLock(hgBuffer); //��������� ������
				memcpy(chBuffer, result.GetBuffer(result.GetLength() + 1), result.GetLength() + 1);
				result.ReleaseBuffer();
				//chBuffer[3] = (TCHAR)0;
				GlobalUnlock(hgBuffer);//������������ ������	
				SetClipboardData(CF_TEXT, hgBuffer);//�������� ����� � ����� ������
				CloseClipboard(); //��������� ����� ������

			}
			
        }
    }
    else
    {
        // TODO: change error code to suit your needs
        wprintf(L"Fatal Error: GetModuleHandle failed\n");
        nRetCode = 1;
    }

    return nRetCode;
}

CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> getSection(CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> &srcString, int firstC, int secondC)
{
	int lenght = 0;
	if (firstC == 0 && secondC == 0)
	{
		lenght = srcString.Find("<!--");
		return srcString.Left(lenght);
	}
	CStringT<char, StrTraitATL<char, ChTraitsCRT<char>>> tag;
	tag.Format("<!--%d%d-->",firstC,secondC);
	int first = srcString.Find(tag);
	first += 9;
	lenght = srcString.Find("<!--",first);
	if (lenght == -1)
	{
		lenght = srcString.GetLength() - first;
		return srcString.Right(lenght);
	}
	lenght -= first;
	return  srcString.Mid(first,lenght);;
}